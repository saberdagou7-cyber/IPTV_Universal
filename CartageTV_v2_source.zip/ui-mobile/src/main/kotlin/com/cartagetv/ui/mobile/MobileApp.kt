package com.cartagetv.ui.mobile
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import com.cartagetv.core.localization.*
import com.cartagetv.core.model.*
import com.cartagetv.feature.playlist.PlaylistViewModel
import androidx.hilt.navigation.compose.hiltViewModel
@Composable fun MobileHome(vm:PlaylistViewModel=hiltViewModel(),onPlay:(Channel)->Unit,onSettings:()->Unit){val s=LocalCartageStrings.current;val channels by vm.filtered.collectAsState();var tab by remember{mutableIntStateOf(0)};Column(Modifier.fillMaxSize().padding(16.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(s.app,style=MaterialTheme.typography.headlineMedium);TextButton(onClick=onSettings){Text(s.settings)}};TabRow(tab){listOf(s.live,s.movies,s.series).forEachIndexed{i,t->Tab(i==tab,{tab=i},text={Text(t)})}};TextField(value=vm.search.collectAsState().value,onValueChange=vm::setQuery,label={Text(s.search)},modifier=Modifier.fillMaxWidth().padding(vertical=8.dp));val kind=MediaKind.entries[tab];LazyVerticalGrid(columns=GridCells.Adaptive(150.dp),contentPadding=PaddingValues(8.dp)){items(channels.filter{it.kind==kind},key={it.id}){c->ElevatedCard(onClick={onPlay(c)},modifier=Modifier.padding(6.dp)){Column{AsyncImage(model=c.logo?:c.poster,contentDescription=null,modifier=Modifier.fillMaxWidth().height(100.dp));Text(c.name,modifier=Modifier.padding(8.dp),maxLines=2)}}}}}}}
