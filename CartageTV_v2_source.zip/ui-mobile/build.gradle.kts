plugins { id("com.android.library"); id("org.jetbrains.kotlin.android"); id("org.jetbrains.kotlin.plugin.compose") }
android { namespace="com.cartagetv.ui.mobile"; compileSdk=37
 defaultConfig { minSdk=21; targetSdk=37 }
 buildFeatures { compose=true }
}

dependencies { implementation(project(":core:model")); implementation(project(":core:localization")); implementation(project(":feature:playlist")); implementation(project(":feature:settings")); implementation(project(":feature:epg")); implementation(project(":feature:player")); implementation("androidx.compose.material3:material3:1.4.0"); implementation("androidx.navigation:navigation-compose:2.9.5"); implementation("io.coil-kt.coil3:coil-compose:3.3.0") }
