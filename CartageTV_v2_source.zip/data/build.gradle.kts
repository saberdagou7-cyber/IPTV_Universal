plugins { id("com.android.library"); id("org.jetbrains.kotlin.android"); id("org.jetbrains.kotlin.plugin.compose") }
android { namespace="com.cartagetv.data"; compileSdk=37
 defaultConfig { minSdk=21; targetSdk=37 }
 buildFeatures { compose=true }
}

dependencies { implementation(project(":core:model")); implementation(project(":core:common")); implementation(project(":core:database")); implementation(project(":core:network")); implementation(project(":domain")); implementation("androidx.datastore:datastore-preferences:1.2.1"); implementation("com.squareup.retrofit2:retrofit:3.0.0"); implementation("com.squareup.okhttp3:okhttp:5.1.0"); implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2") }
