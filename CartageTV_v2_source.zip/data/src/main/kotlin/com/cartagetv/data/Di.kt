package com.cartagetv.data
import android.content.Context
import androidx.room.Room
import com.cartagetv.core.database.CartageDatabase
import com.cartagetv.core.network.*
import com.cartagetv.domain.*
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import javax.inject.Singleton
@Module @InstallIn(SingletonComponent::class) object DataModule {
 @Provides @Singleton fun db(@ApplicationContext c:Context)=Room.databaseBuilder(c,CartageDatabase::class.java,"cartage.db").fallbackToDestructiveMigration().build()
 @Provides @Singleton fun http()=OkHttpClient.Builder().followRedirects(true).followSslRedirects(true).build()
 @Provides @Singleton fun retrofit(client:OkHttpClient)=Retrofit.Builder().baseUrl("https://localhost/").client(client).build()
 @Provides @Singleton fun api(r:Retrofit)=r.create(StreamApi::class.java)
 @Provides @Singleton fun m3u()=M3uParser(); @Provides @Singleton fun xml()=XmltvParser()
 @Provides @Singleton fun channels(db:CartageDatabase,a:StreamApi,p:M3uParser):ChannelRepository=ChannelRepositoryImpl(db,a,p)
 @Provides @Singleton fun epg(db:CartageDatabase,a:StreamApi,p:XmltvParser):EpgRepository=EpgRepositoryImpl(db,a,p)
 @Provides @Singleton fun settings(@ApplicationContext c:Context):SettingsRepository=SettingsRepositoryImpl(c)
}
