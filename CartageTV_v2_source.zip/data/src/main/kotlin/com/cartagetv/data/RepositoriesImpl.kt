package com.cartagetv.data
import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.cartagetv.core.database.*
import com.cartagetv.core.model.*
import com.cartagetv.core.network.*
import com.cartagetv.domain.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
private val Context.ds by preferencesDataStore("cartage_settings")
class ChannelRepositoryImpl(private val db:CartageDatabase,private val api:StreamApi,private val parser:M3uParser):ChannelRepository{
 override fun observeChannels(query:String)=db.channelDao().observe(query).map{it.map{e->Channel(e.id,e.name,e.logo,e.groupName,e.streamUrl,e.epgId,e.poster,e.year,e.rating,e.plot,e.favorite)}}
 override suspend fun refresh(m3uUrl:String)=runCatching{ db.channelDao().clear(); val input=api.get(m3uUrl).byteStream(); val batch=ArrayList<ChannelEntity>(500); var count=0; parser.parse(input).collect{c->batch.add(ChannelEntity(c.id,c.name,c.logo,c.group,c.streamUrl,c.epgId,c.poster,c.year,c.rating,c.plot,c.isFavorite)); if(batch.size==500){db.channelDao().insertAll(batch.toList());count+=batch.size;batch.clear()} }; if(batch.isNotEmpty()){db.channelDao().insertAll(batch);count+=batch.size}; count }.onFailure{it}
 override suspend fun setFavorite(id:String,favorite:Boolean)=db.channelDao().favorite(id,favorite)
}
class EpgRepositoryImpl(private val db:CartageDatabase,private val api:StreamApi,private val parser:XmltvParser):EpgRepository{
 override fun observePrograms(channelId:String)=db.programDao().observe(channelId).map{it.map{p->Program(p.id,p.channelId,p.title,p.description,p.startMs,p.endMs)}}
 override suspend fun refresh(url:String)=runCatching{db.programDao().clear();val batch=ArrayList<ProgramEntity>(500);var n=0;parser.parse(api.get(url).byteStream()).collect{p->batch.add(ProgramEntity(p.id,p.channelId,p.title,p.description,p.startMs,p.endMs));if(batch.size==500){db.programDao().insertAll(batch.toList());n+=batch.size;batch.clear()}};if(batch.isNotEmpty()){db.programDao().insertAll(batch);n+=batch.size};n}
}
class SettingsRepositoryImpl(private val context:Context):SettingsRepository{
 private object K{val playlist=stringPreferencesKey("playlist");val epg=stringPreferencesKey("epg");val locale=stringPreferencesKey("locale")}
 private val prefs=context.ds.data
 override val playlistUrl=prefs.map{it[K.playlist].orEmpty()};override val epgUrl=prefs.map{it[K.epg].orEmpty()};override val locale=prefs.map{it[K.locale]?:"en"};override val configured=playlistUrl.map{it.isNotBlank()}
 override suspend fun save(playlist:String,epg:String){context.ds.edit{it[K.playlist]=playlist;it[K.epg]=epg}}
 override suspend fun setLocale(tag:String){context.ds.edit{it[K.locale]=tag}}
}
