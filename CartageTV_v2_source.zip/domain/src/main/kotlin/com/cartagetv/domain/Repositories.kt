package com.cartagetv.domain
import com.cartagetv.core.model.*
import kotlinx.coroutines.flow.Flow
interface ChannelRepository { fun observeChannels(query:String=""):Flow<List<Channel>>; suspend fun refresh(m3uUrl:String):Result<Int>; suspend fun setFavorite(id:String, favorite:Boolean) }
interface EpgRepository { fun observePrograms(channelId:String):Flow<List<Program>>; suspend fun refresh(url:String):Result<Int> }
interface SettingsRepository { val playlistUrl:Flow<String>; val epgUrl:Flow<String>; val locale:Flow<String>; val configured:Flow<Boolean>; suspend fun save(playlist:String,epg:String); suspend fun setLocale(tag:String) }
