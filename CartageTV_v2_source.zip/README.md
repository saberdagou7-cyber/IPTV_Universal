# CartageTV v2

Production-oriented multi-module Android IPTV/video player architecture for Android TV, phone and tablet.

## Build
1. Open the root folder in Android Studio Quail 4 (2026.1.4) or newer.
2. Use JDK 17.
3. Sync Gradle.
4. Run `./gradlew :app:assembleDebug`.
5. APK: `app/build/outputs/apk/debug/app-debug.apk`.

## Runtime
- User supplies M3U/M3U8 and optional XMLTV URLs.
- No pirated streams are bundled.
- TV mode is detected through UiModeManager.
- M3U and XMLTV parsers stream input and batch Room writes at 500 records.
- Domain is pure Kotlin/JVM.

## Note
The project deliberately keeps localization strings in a small runtime catalog so locale changes can be applied through Compose state without a process restart. Expand the catalog entries as product copy grows.
