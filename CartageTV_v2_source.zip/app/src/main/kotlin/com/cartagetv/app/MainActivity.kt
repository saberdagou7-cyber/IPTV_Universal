package com.cartagetv.app
import android.app.UiModeManager
import android.content.Context
import android.content.res.Configuration
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.hilt.navigation.compose.hiltViewModel
import com.cartagetv.core.localization.*
import com.cartagetv.core.model.Channel
import com.cartagetv.feature.playlist.PlaylistViewModel
import com.cartagetv.feature.settings.SettingsViewModel
import com.cartagetv.ui.mobile.MobileHome
import com.cartagetv.ui.tv.TvHome
import dagger.hilt.android.AndroidEntryPoint
@AndroidEntryPoint class MainActivity:ComponentActivity(){
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{val settings:SettingsViewModel=hiltViewModel();val locale by settings.locale.collectAsStateWithLifecycle();val tv=(getSystemService(Context.UI_MODE_SERVICE) as UiModeManager).currentModeType==Configuration.UI_MODE_TYPE_TELEVISION;MaterialTheme{CompositionLocalProvider(LocalCartageStrings provides stringsFor(locale)){if(tv)TvHome(onPlay={startActivity(android.content.Intent(this,PlayerActivity::class.java).apply{putExtra("url",it.streamUrl);putExtra("name",it.name)})},onSettings={})else MobileHome(onPlay={startActivity(android.content.Intent(this,PlayerActivity::class.java).apply{putExtra("url",it.streamUrl);putExtra("name",it.name)})},onSettings={})}}}}
}
