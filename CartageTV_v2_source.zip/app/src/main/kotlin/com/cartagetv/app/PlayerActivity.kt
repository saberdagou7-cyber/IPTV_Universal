package com.cartagetv.app
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.DisposableEffect
import com.cartagetv.core.model.Channel
import com.cartagetv.core.player.PlayerController
import com.cartagetv.feature.player.PlayerScreen
class PlayerActivity:ComponentActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);val url=intent.getStringExtra("url")?:return;val name=intent.getStringExtra("name")?:"Live";val channel=Channel("play",name,null,"Live",url);val controller=PlayerController(this);setContent{MaterialTheme{PlayerScreen(controller,channel,{finish()});DisposableEffect(Unit){onDispose{controller.release()}}}}}}
