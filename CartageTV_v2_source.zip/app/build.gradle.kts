plugins { id("com.android.application"); id("org.jetbrains.kotlin.android"); id("org.jetbrains.kotlin.plugin.compose"); id("org.jetbrains.kotlin.kapt"); id("com.google.dagger.hilt.android") }
android { namespace="com.cartagetv.app"; compileSdk=37
 defaultConfig { applicationId="com.cartagetv.app"; minSdk=21; targetSdk=37; versionCode=2; versionName="2.0.0" }
 buildFeatures { compose=true }
}

hilt { enableAggregatingTask=true }
kapt { correctErrorTypes=true }
dependencies {
 implementation(project(":core:model")); implementation(project(":core:localization")); implementation(project(":core:player")); implementation(project(":data")); implementation(project(":feature:playlist")); implementation(project(":feature:epg")); implementation(project(":feature:settings")); implementation(project(":feature:player")); implementation(project(":ui-mobile")); implementation(project(":ui-tv"))
 implementation(platform("androidx.compose:compose-bom:2026.08.00")); implementation("androidx.activity:activity-compose:1.12.1"); implementation("androidx.lifecycle:lifecycle-runtime-compose:2.11.0"); implementation("androidx.navigation:navigation-compose:2.9.5"); implementation("com.google.dagger:hilt-android:2.60.1"); kapt("com.google.dagger:hilt-compiler:2.60.1"); implementation("androidx.compose.material3:material3:1.4.0")
}
