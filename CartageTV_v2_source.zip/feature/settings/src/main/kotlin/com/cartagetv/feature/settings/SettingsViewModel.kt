package com.cartagetv.feature.settings
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.cartagetv.domain.SettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
@HiltViewModel class SettingsViewModel @Inject constructor(private val repo:SettingsRepository):ViewModel(){val playlist=repo.playlistUrl.stateIn(viewModelScope,SharingStarted.Eagerly,"");val epg=repo.epgUrl.stateIn(viewModelScope,SharingStarted.Eagerly,"");val locale=repo.locale.stateIn(viewModelScope,SharingStarted.Eagerly,"en");fun save(p:String,e:String)=viewModelScope.launch{repo.save(p,e)};fun setLocale(l:String)=viewModelScope.launch{repo.setLocale(l)}}
