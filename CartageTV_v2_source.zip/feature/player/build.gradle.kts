plugins { id("com.android.library"); id("org.jetbrains.kotlin.android"); id("org.jetbrains.kotlin.plugin.compose") }
android { namespace="com.cartagetv.feature.player"; compileSdk=37
 defaultConfig { minSdk=21; targetSdk=37 }
 buildFeatures { compose=true }
}

dependencies { implementation(project(":core:player")); implementation(project(":core:model")); implementation("androidx.activity:activity-compose:1.12.1"); implementation("androidx.lifecycle:lifecycle-runtime-compose:2.11.0") }
