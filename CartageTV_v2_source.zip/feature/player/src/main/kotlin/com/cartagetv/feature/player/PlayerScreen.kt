package com.cartagetv.feature.player
import android.view.ViewGroup
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.ui.PlayerView
import androidx.media3.ui.AspectRatioFrameLayout
import com.cartagetv.core.player.PlayerController
import com.cartagetv.core.model.Channel
@Composable fun PlayerScreen(controller:PlayerController,channel:Channel,onBack:()->Unit){Box(Modifier.fillMaxSize()){AndroidView(factory={ctx->PlayerView(ctx).apply{useController=false;resizeMode=AspectRatioFrameLayout.RESIZE_MODE_FIT;layoutParams=ViewGroup.LayoutParams(-1,-1)}},update={controller.attach(it,channel.streamUrl)},modifier=Modifier.fillMaxSize());Column(Modifier.fillMaxWidth().padding(24.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(channel.name,style=MaterialTheme.typography.titleLarge);Text("LIVE",color=MaterialTheme.colorScheme.error)}};Row(Modifier.fillMaxSize(),horizontalArrangement=Arrangement.Center,verticalAlignment=Alignment.CenterVertically){Button(onClick={controller.player.playWhenReady=!controller.player.isPlaying}){Text(if(controller.player.isPlaying)"Pause" else "Play")}}}}
