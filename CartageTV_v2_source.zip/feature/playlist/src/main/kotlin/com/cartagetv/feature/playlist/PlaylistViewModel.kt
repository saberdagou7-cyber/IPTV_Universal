package com.cartagetv.feature.playlist
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.cartagetv.core.model.*
import com.cartagetv.domain.ChannelRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
@HiltViewModel class PlaylistViewModel @Inject constructor(private val repo:ChannelRepository):ViewModel(){
 private val query=MutableStateFlow(""); val search=query.asStateFlow(); val channels=repo.observeChannels("").stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList()); val filtered=combine(channels,query){list,q->if(q.isBlank())list else list.filter{it.name.contains(q,true)}}.stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList()); val error=MutableSharedFlow<String>(extraBufferCapacity=1)
 fun setQuery(v:String){query.value=v}; fun refresh(url:String){viewModelScope.launch{repo.refresh(url).onFailure{error.emit(it.message?:"Playlist error")}}}; fun favorite(c:Channel){viewModelScope.launch{repo.setFavorite(c.id,!c.isFavorite)}}
}
