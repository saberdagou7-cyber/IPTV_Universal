plugins { id("com.android.library"); id("org.jetbrains.kotlin.android"); id("org.jetbrains.kotlin.plugin.compose") }
android { namespace="com.cartagetv.feature.epg"; compileSdk=37
 defaultConfig { minSdk=21; targetSdk=37 }
 buildFeatures { compose=true }
}

dependencies { implementation(project(":domain")); implementation(project(":core:model")); implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.11.0"); implementation("androidx.lifecycle:lifecycle-runtime-compose:2.11.0"); implementation("androidx.hilt:hilt-navigation-compose:1.4.0"); implementation("com.google.dagger:hilt-android:2.60.1"); kapt("com.google.dagger:hilt-compiler:2.60.1") }
plugins.apply("org.jetbrains.kotlin.kapt")
