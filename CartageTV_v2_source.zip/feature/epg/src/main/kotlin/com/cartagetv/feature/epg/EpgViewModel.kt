package com.cartagetv.feature.epg
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.cartagetv.core.model.Program
import com.cartagetv.domain.EpgRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.*
@HiltViewModel class EpgViewModel @Inject constructor(private val repo:EpgRepository):ViewModel(){fun programs(id:String):StateFlow<List<Program>> = repo.observePrograms(id).stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())}
