plugins { id("com.android.library"); id("org.jetbrains.kotlin.android"); id("org.jetbrains.kotlin.plugin.compose") }
android { namespace="com.cartagetv.ui.tv"; compileSdk=37
 defaultConfig { minSdk=21; targetSdk=37 }
 buildFeatures { compose=true }
}

dependencies { implementation(project(":core:model")); implementation(project(":core:localization")); implementation(project(":feature:playlist")); implementation("androidx.tv:tv-material:1.1.0"); implementation("androidx.tv:tv-foundation:1.0.0"); implementation("androidx.hilt:hilt-navigation-compose:1.4.0"); implementation("io.coil-kt.coil3:coil-compose:3.3.0") }
