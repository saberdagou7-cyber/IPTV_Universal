package com.cartagetv.ui.tv
import androidx.compose.foundation.graphics.graphicsLayer
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.unit.dp
import androidx.tv.foundation.lazy.list.*
import androidx.tv.material3.*
import coil3.compose.AsyncImage
import com.cartagetv.core.localization.LocalCartageStrings
import com.cartagetv.core.model.*
import com.cartagetv.feature.playlist.PlaylistViewModel
import androidx.hilt.navigation.compose.hiltViewModel
@Composable fun TvHome(vm:PlaylistViewModel=hiltViewModel(),onPlay:(Channel)->Unit,onSettings:()->Unit){val s=LocalCartageStrings.current;val channels by vm.filtered.collectAsState();val fr=remember{FocusRequester()};Column(Modifier.fillMaxSize().padding(40.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(s.app,style=MaterialTheme.typography.displaySmall);Button(onClick=onSettings){Text(s.settings)}};TvLazyColumn{items(MediaKind.entries.toList()){kind->Text(kind.name,style=MaterialTheme.typography.headlineSmall,modifier=Modifier.padding(12.dp));TvLazyRow{items(channels.filter{it.kind==kind}){c->var focused by remember{mutableStateOf(false)};val focusModifier=if(c==channels.firstOrNull())Modifier.focusRequester(fr) else Modifier;Surface(onClick={onPlay(c)},modifier=Modifier.padding(8.dp).then(focusModifier).onFocusChanged{focused=it.isFocused}.graphicsLayer{scaleX=if(focused)1.08f else 1f;scaleY=if(focused)1.08f else 1f}){Column{AsyncImage(model=c.logo?:c.poster,contentDescription=null,modifier=Modifier.size(220.dp,130.dp));Text(c.name,maxLines=1,modifier=Modifier.padding(8.dp))}}}}}}}}}
