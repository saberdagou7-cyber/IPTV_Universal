package com.cartagetv.core.model

data class Channel(
    val id: String, val name: String, val logo: String?, val group: String,
    val streamUrl: String, val epgId: String? = null, val poster: String? = null,
    val year: Int? = null, val rating: String? = null, val plot: String? = null,
    val isFavorite: Boolean = false
) {
    val kind: MediaKind get() = when { group.contains("movie", true) -> MediaKind.MOVIES; group.contains("series", true) -> MediaKind.SERIES; else -> MediaKind.LIVE }
}
enum class MediaKind { LIVE, MOVIES, SERIES }
data class Program(val id: String, val channelId: String, val title: String, val description: String?, val startMs: Long, val endMs: Long)
data class Playlist(val url: String, val channels: List<Channel>)
data class StreamSource(val url: String, val headers: Map<String,String> = emptyMap())
