plugins { id("com.android.library"); id("org.jetbrains.kotlin.android"); id("org.jetbrains.kotlin.plugin.compose") }
android { namespace="com.cartagetv.core.database"; compileSdk=37
 defaultConfig { minSdk=21; targetSdk=37 }
 buildFeatures { compose=true }
}

dependencies { implementation(project(":core:model")); implementation("androidx.room:room-runtime:2.8.1"); implementation("androidx.room:room-ktx:2.8.1"); kapt("androidx.room:room-compiler:2.8.1") }
plugins.apply("org.jetbrains.kotlin.kapt")
