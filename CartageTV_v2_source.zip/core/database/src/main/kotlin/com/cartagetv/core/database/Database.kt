package com.cartagetv.core.database
import androidx.room.*
import kotlinx.coroutines.flow.Flow
@Entity(tableName="channels",indices=[Index("name"),Index("groupName"),Index("epgId")])
data class ChannelEntity(@PrimaryKey val id:String,val name:String,val logo:String?,val groupName:String,val streamUrl:String,val epgId:String?,val poster:String?,val year:Int?,val rating:String?,val plot:String?,val favorite:Boolean=false)
@Entity(tableName="programs",indices=[Index("channelId"),Index("startMs"),Index("endMs")])
data class ProgramEntity(@PrimaryKey val id:String,val channelId:String,val title:String,val description:String?,val startMs:Long,val endMs:Long)
@Dao interface ChannelDao { @Query("SELECT * FROM channels WHERE (:q='') OR name LIKE '%'||:q||'%' ORDER BY groupName,name") fun observe(q:String):Flow<List<ChannelEntity>>; @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun insertAll(v:List<ChannelEntity>); @Query("DELETE FROM channels") suspend fun clear(); @Query("UPDATE channels SET favorite=:favorite WHERE id=:id") suspend fun favorite(id:String,favorite:Boolean) }
@Dao interface ProgramDao { @Query("SELECT * FROM programs WHERE channelId=:channelId ORDER BY startMs") fun observe(channelId:String):Flow<List<ProgramEntity>>; @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun insertAll(v:List<ProgramEntity>); @Query("DELETE FROM programs") suspend fun clear() }
@Database(entities=[ChannelEntity::class,ProgramEntity::class],version=1,exportSchema=false)
abstract class CartageDatabase:RoomDatabase(){ abstract fun channelDao():ChannelDao; abstract fun programDao():ProgramDao }
