plugins { id("com.android.library"); id("org.jetbrains.kotlin.android"); id("org.jetbrains.kotlin.plugin.compose") }
android { namespace="com.cartagetv.core.network"; compileSdk=37
 defaultConfig { minSdk=21; targetSdk=37 }
 buildFeatures { compose=true }
}

dependencies { implementation(project(":core:model")); implementation("com.squareup.retrofit2:retrofit:3.0.0"); implementation("com.squareup.okhttp3:okhttp:5.1.0"); implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.10.2") }
