package com.cartagetv.core.network
import android.util.Xml
import com.cartagetv.core.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.util.UUID
import java.util.regex.Pattern
import org.xmlpull.v1.XmlPullParser
private fun attr(line:String,key:String):String? { val p=Pattern.compile("(?:^|\\s)"+Pattern.quote(key)+"=[\\"]([^\\"]*)[\\"]",Pattern.CASE_INSENSITIVE); return p.matcher(line).let{if(it.find())it.group(1) else null} }
class M3uParser {
 fun parse(input:InputStream):Flow<Channel> = flow { BufferedReader(InputStreamReader(input)).use { r -> var meta:String?=null; for(line0 in r.lineSequence()){ val line=line0.trim(); when { line.startsWith("#EXTINF",true)->meta=line; line.isNotEmpty() && !line.startsWith("#") && meta!=null -> { val m=meta!!; val comma=m.indexOf(','); val name=if(comma>=0)m.substring(comma+1).trim() else "Channel"; emit(Channel(UUID.randomUUID().toString(),name,attr(m,"tvg-logo"),attr(m,"group-title")?:"Other",line,attr(m,"tvg-id"),attr(m,"poster"),Regex("(?:year=|date=)(\\d{4})",RegexOption.IGNORE_CASE).find(m)?.groupValues?.get(1)?.toIntOrNull(),attr(m,"rating"),attr(m,"plot"))); meta=null } } } } }
}
class XmltvParser {
 fun parse(input:InputStream):Flow<Program> = flow {
  val x=Xml.newPullParser(); x.setInput(InputStreamReader(input)); var event=x.eventType; var channel=""; var start=0L; var end=0L; var title=""; var desc:String?=null
  while(event!=XmlPullParser.END_DOCUMENT){ if(event==XmlPullParser.START_TAG){when(x.name){"programme"->{channel=x.getAttributeValue(null,"channel")?:"";start=parseTime(x.getAttributeValue(null,"start"));end=parseTime(x.getAttributeValue(null,"stop"));title="";desc=null};"title"->title=x.nextText();"desc"->desc=x.nextText()}} else if(event==XmlPullParser.END_TAG && x.name=="programme" && title.isNotBlank()) emit(Program(UUID.randomUUID().toString(),channel,title,desc,start,end)); event=x.next() }
 }
 private fun parseTime(v:String?):Long=try{if(v.isNullOrBlank())0 else java.text.SimpleDateFormat("yyyyMMddHHmmss Z",java.util.Locale.US).parse(v.trim().replace(Regex("^(.{14})\\s*([+-]\\d{4}).*$"),"$1 $2"))?.time?:0}catch(_:Exception){0}
}
