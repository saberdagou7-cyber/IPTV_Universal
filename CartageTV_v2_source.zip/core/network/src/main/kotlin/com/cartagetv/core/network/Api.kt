package com.cartagetv.core.network
import okhttp3.ResponseBody
import retrofit2.http.GET
import retrofit2.http.Url
interface StreamApi { @GET suspend fun get(@Url url:String):ResponseBody }
