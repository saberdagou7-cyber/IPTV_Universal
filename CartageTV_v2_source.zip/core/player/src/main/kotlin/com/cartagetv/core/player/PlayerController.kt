package com.cartagetv.core.player
import android.content.Context
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
class PlayerController(context:Context){
 val player=ExoPlayer.Builder(context).build()
 fun attach(view:PlayerView,url:String){view.player=player;view.useController=false;if(player.currentMediaItem?.localConfiguration?.uri?.toString()!=url){player.setMediaItem(MediaItem.fromUri(url));player.prepare()};player.playWhenReady=true}
 fun release(){player.release()}
}
