plugins { id("com.android.library"); id("org.jetbrains.kotlin.android"); id("org.jetbrains.kotlin.plugin.compose") }
android { namespace="com.cartagetv.core.player"; compileSdk=37
 defaultConfig { minSdk=21; targetSdk=37 }
 buildFeatures { compose=true }
}

dependencies { implementation("androidx.media3:media3-exoplayer:1.11.0"); implementation("androidx.media3:media3-ui:1.11.0"); implementation("androidx.media3:media3-common:1.11.0") }
