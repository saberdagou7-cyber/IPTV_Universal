package com.cartagetv.core.localization
import androidx.compose.runtime.*
import androidx.compose.ui.unit.LayoutDirection

data class Strings(val app:String="CartageTV",val live:String="Live TV",val movies:String="Movies",val series:String="Series",val favorites:String="Favorites",val search:String="Search",val settings:String="Settings",val epg:String="Guide",val play:String="Play",val retry:String="Retry",val playlist:String="Playlist URL",val epgUrl:String="EPG URL",val save:String="Save",val noChannels:String="No channels")
private val rtl=setOf("ar","fa","ur","he")
private val langs=listOf("en","fr","ar","de","es","it","pt","nl","tr","ru","uk","pl","ro","el","sv","da","no","fi","cs","sk","hu","bg","hr","sr","sl","id","ms","hi","bn")
private val translations=mapOf("fr" to Strings(live="TV en direct",movies="Films",series="Séries",favorites="Favoris",search="Rechercher",settings="Paramètres",epg="Guide",play="Lire",retry="Réessayer",playlist="URL Playlist",epgUrl="URL EPG",save="Enregistrer",noChannels="Aucune chaîne"),"ar" to Strings(live="البث المباشر",movies="الأفلام",series="المسلسلات",favorites="المفضلة",search="بحث",settings="الإعدادات",epg="الدليل",play="تشغيل",retry="إعادة المحاولة",playlist="رابط القائمة",epgUrl="رابط دليل البرامج",save="حفظ",noChannels="لا توجد قنوات"))
fun supportedLocales():List<String> = langs
fun stringsFor(tag:String):Strings = translations[tag.lowercase().substringBefore('-')] ?: Strings()
val LocalCartageStrings=staticCompositionLocalOf { Strings() }
@Composable fun CartageLocalization(localeTag:String,content:@Composable()->Unit){CompositionLocalProvider(LocalCartageStrings provides stringsFor(localeTag),LocalLayoutDirection provides if(rtl.contains(localeTag.substringBefore('-'))) LayoutDirection.Rtl else LayoutDirection.Ltr,content=content)}
