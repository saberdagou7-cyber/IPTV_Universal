pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement { repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS); repositories { google(); mavenCentral() } }
rootProject.name="CartageTV"
include(":app", ":core:model", ":core:common", ":core:localization", ":core:database", ":core:network", ":core:player", ":domain", ":data", ":feature:playlist", ":feature:epg", ":feature:player", ":feature:settings", ":ui-mobile", ":ui-tv")
