package com.cartage
import android.app.UiModeManager
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Configuration
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.net.URL

data class Channel(val name:String,val url:String,val group:String)
object M3UParser{private val rx=Regex("([A-Za-z0-9_-]+)=\"([^\"]*)\"");fun parse(t:String):List<Channel>{val out=mutableListOf<Channel>();var a=emptyMap<String,String>();var n="";t.lineSequence().forEach{l->val s=l.trim();when{ s.startsWith("#EXTINF",true)->{a=rx.findAll(s).associate{it.groupValues[1].lowercase() to it.groupValues[2]};n=s.substringAfter(",","").trim()};s.startsWith("#")->Unit;s.isNotBlank()->{out+=Channel(n.ifBlank{s},s,a["group-title"]?:"General");n="";a=emptyMap()}}};return out}}
@HiltViewModel class VM @Inject constructor():ViewModel(){var channels by mutableStateOf(emptyList<Channel>());var error by mutableStateOf("");fun load(url:String){viewModelScope.launch(Dispatchers.IO){runCatching{M3UParser.parse(URL(url).readText())}.onSuccess{channels=it}.onFailure{error=it.message.orEmpty()}}}}
@Composable fun CartageRoot(){val c=LocalContext.current;val ui=c.getSystemService(UiModeManager::class.java);val tv=ui?.currentModeType==Configuration.UI_MODE_TYPE_TELEVISION||c.packageManager.hasSystemFeature(PackageManager.FEATURE_LEANBACK);var tab by rememberSaveable{mutableIntStateOf(0)};val labels=listOf("Home","Live","Guide","VOD","Settings");if(tv)Row(Modifier.fillMaxSize()){NavigationRail{labels.forEachIndexed{i,l->NavigationRailItem(i==tab,{tab=i},{Icon(Icons.Default.Tv,l)},{Text(l)})}};MainContent(tab)}else Scaffold(bottomBar={NavigationBar{labels.forEachIndexed{i,l->NavigationBarItem(i==tab,{tab=i},{Icon(Icons.Default.Tv,l)},{Text(l)})}}}){MainContent(tab,Modifier.padding(it))}}
@Composable fun MainContent(tab:Int,m:Modifier=Modifier){when(tab){0->Column(m.fillMaxSize().padding(32.dp)){Text("Cartage TV",style=MaterialTheme.typography.displaySmall);Text("IPTV • TV • Mobile • Tablet")};1->Live(m);2->Column(m.fillMaxSize().padding(24.dp)){Text("Guide / EPG",style=MaterialTheme.typography.headlineMedium);Text("XMLTV integration ready")};3->Column(m.fillMaxSize().padding(24.dp)){Text("VOD",style=MaterialTheme.typography.headlineMedium)};4->Settings(m)}}
@Composable fun Settings(m:Modifier){val vm:VM=hiltViewModel();var u by rememberSaveable{mutableStateOf("")};Column(m.fillMaxSize().padding(24.dp),verticalArrangement=Arrangement.spacedBy(16.dp)){Text("Settings",style=MaterialTheme.typography.headlineMedium);OutlinedTextField(u,{u=it},label={Text("M3U / M3U8 URL")},modifier=Modifier.fillMaxWidth());Button({vm.load(u)},enabled=u.startsWith("http")){Text("Importer")};if(vm.error.isNotBlank())Text(vm.error)}}
@Composable fun Live(m:Modifier){val vm:VM=hiltViewModel();var url by remember{mutableStateOf<String?>(null)};Column(m.fillMaxSize().padding(24.dp)){Text("Live TV",style=MaterialTheme.typography.headlineMedium);if(vm.channels.isEmpty())Text("Ajoutez une playlist dans Settings")else LazyVerticalGrid(GridCells.Adaptive(190.dp),contentPadding=PaddingValues(8.dp)){items(vm.channels){ch->var f by remember{mutableStateOf(false)};Surface(Modifier.height(110.dp).onFocusChanged{f=it.isFocused}.focusable().clickable{url=ch.url}.graphicsLayer{val s=if(f)1.08f else 1f;scaleX=s;scaleY=s},tonalElevation=if(f)8.dp else 2.dp){Column(Modifier.padding(14.dp)){Text(ch.name);Text(ch.group,style=MaterialTheme.typography.labelSmall)}}}}};if(url!=null)Player(url!!)}}
@Composable fun Player(url:String){val context=LocalContext.current;val p=remember{ExoPlayer.Builder(context).build()};DisposableEffect(url){p.setMediaItem(MediaItem.fromUri(url));p.prepare();p.play();onDispose{p.stop();p.release()}};AndroidView({PlayerView(it).apply{player=p}},Modifier.fillMaxSize())}
