package com.cartage
import android.app.Application
import dagger.hilt.android.HiltAndroidApp
@HiltAndroidApp class CartageApplication:Application()