# Cartage TV — International Intelligent 2.0

A single Android codebase for Android TV, phones and tablets.

## Included
- 30-language language model with RTL metadata (Arabic, Hebrew, Persian).
- Persistent language selection using AndroidX DataStore Preferences.
- Locale-aware date/time formatting.
- Adaptive TV/mobile navigation.
- M3U/M3U8 parsing with IPTV metadata.
- Smart channel classification and grouping.
- Accent-insensitive/fuzzy channel search.
- Local recommendation engine based on favorites, viewing history and preferred language.
- Local playlist persistence using DataStore.
- Media3 playback for HLS/DASH/RTSP-capable streams.
- Xtream API interface foundation.

## Important
This package is a production-oriented foundation, not a claim that every IPTV provider or every VOD/EPG backend is universally compatible. Provider-specific authentication, XMLTV parsing, VOD/series repositories, DRM and cloud metadata providers can be added behind the existing data layer.

Open the folder in Android Studio with JDK 17 and sync Gradle.
