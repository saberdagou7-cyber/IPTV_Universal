package com.cartage.core.device

import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.app.UiModeManager

enum class DeviceType { TV, TABLET, PHONE }
object DeviceTypeChecker {
    fun type(context: Context): DeviceType {
        val ui = context.getSystemService(UiModeManager::class.java)
        if (ui?.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION || context.packageManager.hasSystemFeature(PackageManager.FEATURE_LEANBACK)) return DeviceType.TV
        val smallest = context.resources.configuration.smallestScreenWidthDp
        return if (smallest >= 600) DeviceType.TABLET else DeviceType.PHONE
    }
}
