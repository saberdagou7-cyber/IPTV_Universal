package com.cartage.domain.model

data class Channel(
    val id: String,
    val name: String,
    val logo: String? = null,
    val groupTitle: String = "General",
    val tvgId: String? = null,
    val tvgCountry: String? = null,
    val tvgLanguage: String? = null,
    val channelNumber: String? = null,
    val streamUrl: String,
    val category: ChannelCategory = ChannelCategory.OTHER
)
enum class ChannelCategory { NEWS, SPORTS, MOVIES, KIDS, MUSIC, ENTERTAINMENT, DOCUMENTARY, GENERAL, OTHER }
