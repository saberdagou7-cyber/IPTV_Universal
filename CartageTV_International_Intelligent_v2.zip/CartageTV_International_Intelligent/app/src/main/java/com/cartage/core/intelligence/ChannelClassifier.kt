package com.cartage.core.intelligence

import com.cartage.domain.model.ChannelCategory

object ChannelClassifier {
    private val rules = mapOf(
        ChannelCategory.NEWS to listOf("news", "cnn", "bbc", "france 24", "aljazeera", "sky news", "euronews"),
        ChannelCategory.SPORTS to listOf("sport", "bein", "espn", "eurosport", "sky sport", "canal+ sport", "dazn"),
        ChannelCategory.MOVIES to listOf("movie", "cinema", "film", "ciné", "hbo", "cinemax", "paramount"),
        ChannelCategory.KIDS to listOf("kids", "cartoon", "nick", "disney", "gulli", "baby"),
        ChannelCategory.MUSIC to listOf("music", "mtv", "trace", "melody", "hits"),
        ChannelCategory.DOCUMENTARY to listOf("discovery", "nat geo", "national geographic", "history", "documentary"),
        ChannelCategory.ENTERTAINMENT to listOf("entertainment", "show", "series", "drama", "reality")
    )
    fun classify(name: String, group: String): ChannelCategory {
        val s = "$name $group".lowercase()
        return rules.entries.firstOrNull { (_, keys) -> keys.any(s::contains) }?.key ?: ChannelCategory.GENERAL
    }
}
