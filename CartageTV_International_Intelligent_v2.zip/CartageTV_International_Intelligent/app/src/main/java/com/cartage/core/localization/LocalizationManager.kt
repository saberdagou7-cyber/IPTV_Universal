package com.cartage.core.localization

import androidx.compose.runtime.compositionLocalOf
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

class LocalizationManager(val language: Language, val locale: Locale) {
    fun formatDateTime(value: LocalDateTime = LocalDateTime.now()): String = DateTimeFormatter.ofPattern("EEE, MMM d • HH:mm", locale).format(value)
    fun formatTime(value: LocalTime = LocalTime.now()): String = DateTimeFormatter.ofPattern("HH:mm", locale).format(value)
}
val LocalLocalization = compositionLocalOf { LocalizationManager(Language.ENGLISH, Locale.ENGLISH) }
