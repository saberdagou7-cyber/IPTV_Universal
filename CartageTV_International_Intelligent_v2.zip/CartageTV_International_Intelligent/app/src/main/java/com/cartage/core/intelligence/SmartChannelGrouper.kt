package com.cartage.core.intelligence

import com.cartage.core.localization.Language
import com.cartage.domain.model.Channel
import com.cartage.domain.model.ChannelCategory

object SmartChannelGrouper {
    private val countries = mapOf("fr" to "France", "de" to "Germany", "es" to "Spain", "it" to "Italy", "pt" to "Portugal", "tr" to "Türkiye", "ru" to "Russia", "zh" to "China", "ja" to "Japan", "ko" to "Korea", "en" to "International", "ar" to "Arabic")
    fun group(channels: List<Channel>, preferred: Language): LinkedHashMap<String, List<Channel>> {
        val result = LinkedHashMap<String, MutableList<Channel>>()
        val preferredName = countries[preferred.code] ?: preferred.nativeName
        channels.forEach { ch ->
            val key = when {
                ch.tvgLanguage?.lowercase()?.startsWith(preferred.code) == true -> "⭐ $preferredName"
                ch.category == ChannelCategory.NEWS -> "News"
                ch.category == ChannelCategory.SPORTS -> "Sports"
                ch.category == ChannelCategory.MOVIES -> "Movies"
                ch.category == ChannelCategory.KIDS -> "Kids"
                ch.category == ChannelCategory.MUSIC -> "Music"
                ch.category == ChannelCategory.DOCUMENTARY -> "Documentaries"
                ch.category == ChannelCategory.ENTERTAINMENT -> "Entertainment"
                ch.groupTitle.isNotBlank() && !ch.groupTitle.equals("General", true) -> ch.groupTitle.trim()
                else -> "Other"
            }
            result.getOrPut(key) { mutableListOf() }.add(ch)
        }
        return LinkedHashMap(result.mapValues { (_, v) -> v.sortedBy { it.name.lowercase() } })
    }
}
