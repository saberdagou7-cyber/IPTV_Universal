package com.cartage.core.localization

import java.util.Locale

enum class Language(val code: String, val displayName: String, val nativeName: String, val rtl: Boolean = false) {
    ENGLISH("en", "English", "English"), FRENCH("fr", "French", "Français"), ARABIC("ar", "Arabic", "العربية", true),
    SPANISH("es", "Spanish", "Español"), GERMAN("de", "German", "Deutsch"), ITALIAN("it", "Italian", "Italiano"),
    PORTUGUESE("pt", "Portuguese", "Português"), TURKISH("tr", "Turkish", "Türkçe"), RUSSIAN("ru", "Russian", "Русский"),
    CHINESE("zh", "Chinese", "中文"), JAPANESE("ja", "Japanese", "日本語"), KOREAN("ko", "Korean", "한국어"),
    DUTCH("nl", "Dutch", "Nederlands"), POLISH("pl", "Polish", "Polski"), SWEDISH("sv", "Swedish", "Svenska"),
    DANISH("da", "Danish", "Dansk"), NORWEGIAN("no", "Norwegian", "Norsk"), FINNISH("fi", "Finnish", "Suomi"),
    CZECH("cs", "Czech", "Čeština"), GREEK("el", "Greek", "Ελληνικά"), ROMANIAN("ro", "Romanian", "Română"),
    HUNGARIAN("hu", "Hungarian", "Magyar"), UKRAINIAN("uk", "Ukrainian", "Українська"), INDONESIAN("id", "Indonesian", "Bahasa Indonesia"),
    MALAY("ms", "Malay", "Bahasa Melayu"), HEBREW("he", "Hebrew", "עברית", true), THAI("th", "Thai", "ไทย"),
    VIETNAMESE("vi", "Vietnamese", "Tiếng Việt"), HINDI("hi", "Hindi", "हिन्दी"), PERSIAN("fa", "Persian", "فارسی", true);

    fun toLocale(): Locale = Locale.forLanguageTag(code)
    companion object {
        fun fromCode(code: String): Language = entries.firstOrNull { it.code == code } ?: ENGLISH
        fun fromLocale(locale: Locale): Language = entries.firstOrNull { it.code == locale.language } ?: ENGLISH
    }
}
