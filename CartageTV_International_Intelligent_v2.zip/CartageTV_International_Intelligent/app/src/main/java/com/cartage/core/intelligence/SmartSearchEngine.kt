package com.cartage.core.intelligence

import com.cartage.domain.model.Channel

object SmartSearchEngine {
    private fun normalize(s: String) = s.lowercase().normalizeAccents().replace(Regex("[^a-z0-9 ]"), " ").replace(Regex("\s+"), " ").trim()
    private fun String.normalizeAccents(): String = java.text.Normalizer.normalize(this, java.text.Normalizer.Form.NFD).replace(Regex("\p{Mn}+"), "")
    fun search(query: String, channels: List<Channel>): List<Channel> {
        if (query.isBlank()) return channels
        val q = normalize(query)
        return channels.map { ch ->
            val n = normalize(ch.name); val g = normalize(ch.groupTitle)
            val score = when { n == q -> 100; n.startsWith(q) -> 80; n.contains(q) -> 60; g.contains(q) -> 40; editDistance(n, q) <= 2 -> 20; else -> 0 }
            ch to score
        }.filter { it.second > 0 }.sortedByDescending { it.second }.map { it.first }
    }
    private fun editDistance(a: String, b: String): Int { val d=Array(a.length+1){IntArray(b.length+1)}; for(i in 0..a.length)d[i][0]=i; for(j in 0..b.length)d[0][j]=j; for(i in 1..a.length)for(j in 1..b.length)d[i][j]=minOf(d[i-1][j]+1,d[i][j-1]+1,d[i-1][j-1]+if(a[i-1]==b[j-1])0 else 1); return d[a.length][b.length] }
}
