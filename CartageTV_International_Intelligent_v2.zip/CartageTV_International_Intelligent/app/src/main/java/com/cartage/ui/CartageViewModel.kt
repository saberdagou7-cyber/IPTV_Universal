package com.cartage.ui
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.cartage.core.intelligence.*
import com.cartage.core.localization.Language
import com.cartage.data.local.LocalLibrary
import com.cartage.data.remote.M3UParser
import com.cartage.domain.model.Channel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.net.URL

class CartageViewModel(app:Application):AndroidViewModel(app){
 private val lib=LocalLibrary(app); private val _channels=MutableStateFlow<List<Channel>>(emptyList()); val channels:StateFlow<List<Channel>>=_channels.asStateFlow(); private val _favorites=MutableStateFlow<Set<String>>(emptySet()); val favorites=_favorites.asStateFlow(); private val _history=MutableStateFlow<Map<String,Long>>(emptyMap()); val history=_history.asStateFlow(); private val _error=MutableStateFlow(""); val error=_error.asStateFlow(); private val _loading=MutableStateFlow(false); val loading=_loading.asStateFlow()
 init{viewModelScope.launch{_channels.value=lib.channels();_favorites.value=lib.favorites();_history.value=lib.history()}}
 fun importM3U(url:String){if(!url.startsWith("http")){_error.value="Enter a valid HTTP/HTTPS URL";return};viewModelScope.launch(Dispatchers.IO){_loading.value=true;runCatching{M3UParser.parse(URL(url).readText())}.onSuccess{_channels.value=it;lib.saveChannels(it);_error.value=""}.onFailure{_error.value=it.message.orEmpty()};_loading.value=false}}
 fun toggleFavorite(id:String){viewModelScope.launch{lib.toggleFavorite(id);_favorites.value=lib.favorites()}}
 fun watched(id:String){viewModelScope.launch{lib.markWatched(id);_history.value=lib.history()}}
 fun search(q:String)=SmartSearchEngine.search(q,_channels.value)
 fun grouped(language:Language)=SmartChannelGrouper.group(_channels.value,language)
 fun recommendations(language:Language)=RecommendationEngine.recommend(_channels.value,_favorites.value,_history.value,language.code)
}
