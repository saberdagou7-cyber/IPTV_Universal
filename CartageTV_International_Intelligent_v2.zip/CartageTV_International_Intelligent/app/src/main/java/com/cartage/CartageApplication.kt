package com.cartage

import android.app.Application
import android.content.Context
import android.content.res.Configuration
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.cartage.core.localization.Language
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import java.util.Locale

private val Context.settingsDataStore by preferencesDataStore(name = "cartage_settings")

@HiltAndroidApp
class CartageApplication : Application() {
    companion object {
        private val LANGUAGE_KEY = stringPreferencesKey("app_language")
        fun selectedLanguage(context: Context): Language {
            val code = runBlocking { context.settingsDataStore.data.first()[LANGUAGE_KEY] }
            return code?.let(Language::fromCode) ?: Language.fromLocale(Locale.getDefault())
        }
        suspend fun saveLanguage(context: Context, language: Language) {
            context.settingsDataStore.edit { it[LANGUAGE_KEY] = language.code }
        }
        fun localizedContext(base: Context): Context {
            val language = selectedLanguage(base)
            val locale = language.toLocale()
            Locale.setDefault(locale)
            val config = Configuration(base.resources.configuration)
            config.setLocale(locale)
            config.setLayoutDirection(locale)
            return base.createConfigurationContext(config)
        }
    }

    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(localizedContext(base))
    }
}
