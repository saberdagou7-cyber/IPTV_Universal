package com.cartage.data.local

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.cartage.domain.model.Channel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.libraryStore by preferencesDataStore("cartage_library")
class LocalLibrary(private val context: Context) {
    private val channelsKey=stringPreferencesKey("channels_json")
    private val favoritesKey=stringPreferencesKey("favorites")
    private val historyKey=stringPreferencesKey("history_json")
    suspend fun saveChannels(channels: List<Channel>) = context.libraryStore.edit { it[channelsKey]=JSONArray(channels.map{c->JSONObject().apply{put("id",c.id);put("name",c.name);put("logo",c.logo);put("group",c.groupTitle);put("country",c.tvgCountry);put("language",c.tvgLanguage);put("url",c.streamUrl);put("category",c.category.name)}}).toString() }
    suspend fun channels(): List<Channel> = context.libraryStore.data.map { it[channelsKey].orEmpty() }.first().let(::decodeChannels)
    suspend fun favorites(): Set<String> = context.libraryStore.data.map { it[favoritesKey].orEmpty().split("|").filter(String::isNotBlank).toSet() }.first()
    suspend fun toggleFavorite(id:String) = context.libraryStore.edit { p -> val s=p[favoritesKey].orEmpty().split("|").filter(String::isNotBlank).toMutableSet(); if(!s.add(id))s.remove(id); p[favoritesKey]=s.joinToString("|") }
    suspend fun history(): Map<String,Long> = context.libraryStore.data.map { it[historyKey].orEmpty() }.first().let { raw -> if(raw.isBlank()) emptyMap() else JSONObject(raw).let { o -> o.keys().asSequence().associateWith { o.getLong(it) } } }
    suspend fun markWatched(id:String) = context.libraryStore.edit { p -> val o=JSONObject(p[historyKey].orEmpty()); o.put(id,(o.optLong(id,0)+1).coerceAtMost(100)); p[historyKey]=o.toString() }
    private fun decodeChannels(raw:String):List<Channel> { if(raw.isBlank())return emptyList(); val a=JSONArray(raw); return (0 until a.length()).map{val o=a.getJSONObject(it); Channel(o.getString("id"),o.getString("name"),o.optString("logo").ifBlank{null},o.optString("group","General"),tvgCountry=o.optString("country").ifBlank{null},tvgLanguage=o.optString("language").ifBlank{null},streamUrl=o.getString("url"),category=com.cartage.domain.model.ChannelCategory.valueOf(o.optString("category","OTHER")))} }
}
