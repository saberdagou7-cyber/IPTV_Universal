package com.cartage.data.remote

import com.cartage.core.intelligence.ChannelClassifier
import com.cartage.domain.model.Channel
import java.net.URL
import java.util.UUID

object M3UParser {
    private val attr = Regex("([A-Za-z0-9_-]+)=(\"[^\"]*\"|[^\s]*)")
    fun parse(text: String): List<Channel> {
        val result = mutableListOf<Channel>(); var meta = emptyMap<String,String>(); var title = ""
        text.lineSequence().forEach { raw -> val line=raw.trim(); when {
            line.startsWith("#EXTINF", true) -> { meta=attr.findAll(line).associate { it.groupValues[1].lowercase() to it.groupValues[2].trim('\"') }; title=line.substringAfterLast(",").trim() }
            line.startsWith("#") || line.isBlank() -> Unit
            else -> { val group=meta["group-title"].orEmpty().ifBlank{"General"}; result += Channel(meta["tvg-id"] ?: UUID.randomUUID().toString(), title.ifBlank{meta["tvg-name"].orEmpty().ifBlank{line}}, meta["tvg-logo"], group, meta["tvg-id"], meta["tvg-country"], meta["tvg-language"], meta["tvg-chno"], line, ChannelClassifier.classify(title, group)); title=""; meta=emptyMap() }
        }}; return result
    }
    fun parseUrl(url: String): List<Channel> = parse(URL(url).readText())
}
