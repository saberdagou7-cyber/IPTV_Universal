package com.cartage.data.remote

import retrofit2.http.GET
import retrofit2.http.Query

data class XtreamChannelDto(val num:Int?=null, val name:String?=null, val stream_id:Int?=null, val stream_icon:String?=null, val category_name:String?=null)
interface XtreamApi {
    @GET("player_api.php") suspend fun live(@Query("username") user:String,@Query("password") pass:String,@Query("action") action:String="get_live_streams"): List<XtreamChannelDto>
}
