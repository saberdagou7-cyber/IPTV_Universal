package com.cartage.core.intelligence

import com.cartage.domain.model.Channel

object RecommendationEngine {
    fun recommend(channels: List<Channel>, favorites: Set<String>, history: Map<String, Long>, preferredLanguage: String): List<Channel> =
        channels.map { c ->
            val favorite = if (c.id in favorites) 100 else 0
            val watched = (history[c.id] ?: 0L).coerceAtMost(60L)
            val lang = if (c.tvgLanguage?.lowercase()?.startsWith(preferredLanguage.lowercase()) == true) 20 else 0
            val score = favorite + watched + lang
            c to score
        }.sortedByDescending { it.second }.map { it.first }.distinctBy { it.id }.take(20)
}
