package com.cartage.ui

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.clickable
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.cartage.CartageApplication
import com.cartage.R
import com.cartage.core.device.DeviceTypeChecker
import com.cartage.core.localization.*
import com.cartage.core.ui.AdaptiveRoot
import com.cartage.domain.model.Channel

@Composable fun CartageApp(onLanguageSelected:(Language)->Unit){
 val context=LocalContext.current; val language=CartageApplication.selectedLanguage(context); val lm=remember(language){LocalizationManager(language,language.toLocale())}; CompositionLocalProvider(LocalLocalization provides lm){AdaptiveRoot{MainShell(onLanguageSelected)}}
}
@Composable private fun MainShell(onLanguageSelected:(Language)->Unit){val type=DeviceTypeChecker.type(LocalContext.current);var tab by rememberSaveable{mutableIntStateOf(0)};val labels=listOf(stringResource(R.string.home),stringResource(R.string.live_tv),stringResource(R.string.guide),stringResource(R.string.vod),stringResource(R.string.settings));val icons=listOf(Icons.Default.Home,Icons.Default.Tv,Icons.Default.List,Icons.Default.Movie,Icons.Default.Settings); if(type==com.cartage.core.device.DeviceType.TV){Row(Modifier.fillMaxSize()){NavigationRail{labels.forEachIndexed{i,l->NavigationRailItem(selected=i==tab,onClick={tab=i},icon={Icon(icons[i],null)},label={Text(l)})}};MainContent(tab,Modifier.weight(1f),onLanguageSelected)}}else{Scaffold(bottomBar={NavigationBar{labels.forEachIndexed{i,l->NavigationBarItem(selected=i,onClick={tab=i},icon={Icon(icons[i],null)},label={Text(l)})}}}){MainContent(tab,Modifier.padding(it),onLanguageSelected)}}}
@Composable private fun MainContent(tab:Int,m:Modifier,onLanguageSelected:(Language)->Unit){when(tab){0->Home(m);1->Live(m);2->SimplePage(m,stringResource(R.string.guide));3->SimplePage(m,stringResource(R.string.vod));4->Settings(m,onLanguageSelected)}}
@Composable private fun Home(m:Modifier){val vm:CartageViewModel=viewModel();val lang=LocalLocalization.current.language;val rec=vm.recommendations(lang);LazyColumn(m.fillMaxSize().padding(24.dp),verticalArrangement=Arrangement.spacedBy(18.dp)){item{Text(stringResource(R.string.home_greeting),style=MaterialTheme.typography.headlineLarge)};item{Text(stringResource(R.string.recommended),style=MaterialTheme.typography.titleLarge)};items(rec.take(8)){Text("• ${it.name}")};item{Text(LocalLocalization.current.formatDateTime(),style=MaterialTheme.typography.labelLarge)}}}
@Composable private fun Live(m:Modifier){val vm:CartageViewModel=viewModel();val lang=LocalLocalization.current.language;var query by rememberSaveable{mutableStateOf("")};var playing by remember{mutableStateOf<Channel?>(null)};val all=vm.channels.collectAsState().value;val filtered=remember(query,all){vm.search(query)};Column(m.fillMaxSize().padding(16.dp)){OutlinedTextField(query,{query=it},label={Text(stringResource(R.string.search))},singleLine=true,modifier=Modifier.fillMaxWidth());Spacer(Modifier.height(12.dp));val groups=if(query.isBlank())vm.grouped(lang) else linkedMapOf(stringResource(R.string.search_results) to filtered);LazyColumn(Modifier.weight(1f)){groups.forEach{(title,chs)->item{Text(title,style=MaterialTheme.typography.titleMedium,modifier=Modifier.padding(8.dp))};item{LazyVerticalGrid(GridCells.Adaptive(180.dp),modifier=Modifier.height(((chs.size+3)/4*118).coerceAtMost(500).dp),contentPadding=PaddingValues(6.dp)){items(chs){ChannelCard(it,vm, onPlay={playing=it})}}}}};if(playing!=null)Player(playing!!.streamUrl)}}
@Composable private fun ChannelCard(ch:Channel,vm:CartageViewModel,onPlay:()->Unit){var focused by remember{mutableStateOf(false)};val fav=vm.favorites.collectAsState().value.contains(ch.id);Surface(modifier=Modifier.padding(6.dp).height(100.dp).onFocusChanged{focused=it.isFocused}.focusable().clickable{vm.watched(ch.id);onPlay()}.graphicsLayer{val s=if(focused)1.08f else 1f;scaleX=s;scaleY=s},tonalElevation=if(focused)8.dp else 2.dp){Column(Modifier.padding(12.dp)){Text(ch.name,maxLines=2);Text(ch.category.name,style=MaterialTheme.typography.labelSmall);Text(if(fav)"★" else "☆",modifier=Modifier.clickable{vm.toggleFavorite(ch.id)})}}}
@Composable private fun Player(url:String){val ctx=LocalContext.current;val p=remember(url){ExoPlayer.Builder(ctx).build()};DisposableEffect(url){p.setMediaItem(MediaItem.fromUri(Uri.parse(url)));p.prepare();p.play();onDispose{p.release()}};AndroidView({PlayerView(it).apply{player=p;useController=true}},Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background))}
@Composable private fun SimplePage(m:Modifier,title:String){Column(m.fillMaxSize().padding(24.dp)){Text(title,style=MaterialTheme.typography.headlineMedium);Spacer(Modifier.height(12.dp));Text(stringResource(R.string.feature_ready))}}
@Composable private fun Settings(m:Modifier,onLanguageSelected:(Language)->Unit){val vm:CartageViewModel=viewModel();var url by rememberSaveable{mutableStateOf("")};var expanded by remember{mutableStateOf(false)};val lang=LocalLocalization.current.language;LazyColumn(m.fillMaxSize().padding(24.dp),verticalArrangement=Arrangement.spacedBy(16.dp)){item{Text(stringResource(R.string.settings),style=MaterialTheme.typography.headlineMedium)};item{OutlinedTextField(url,{url=it},label={Text(stringResource(R.string.m3u_url))},modifier=Modifier.fillMaxWidth())};item{Button(onClick={vm.importM3U(url)},enabled=url.startsWith("http")){Text(stringResource(R.string.import_playlist))}};item{if(vm.loading.collectAsState().value)CircularProgressIndicator();val e=vm.error.collectAsState().value;if(e.isNotBlank())Text(e)} };item{ExposedDropdownMenuBox(expanded=expanded,onExpandedChange={expanded=!expanded}){OutlinedTextField(value=lang.nativeName,onValueChange={},readOnly=true,label={Text(stringResource(R.string.select_language))},trailingIcon={ExposedDropdownMenuDefaults.TrailingIcon(expanded)},modifier=Modifier.menuAnchor().fillMaxWidth());ExposedDropdownMenu(expanded=expanded,onDismissRequest={expanded=false}){Language.entries.forEach{l->DropdownMenuItem(text={Text(l.nativeName)},onClick={expanded=false;onLanguageSelected(l)})}}}}}}
