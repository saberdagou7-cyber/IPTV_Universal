package com.cartage.ui.theme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
private val Dark=darkColorScheme(background=Color(0xFF0A0A0F),surface=Color(0xFF111118),primary=Color(0xFF00D4FF),secondary=Color(0xFFFF007F))
@Composable fun CartageTheme(content:@Composable ()->Unit){MaterialTheme(colorScheme=Dark,content=content)}
