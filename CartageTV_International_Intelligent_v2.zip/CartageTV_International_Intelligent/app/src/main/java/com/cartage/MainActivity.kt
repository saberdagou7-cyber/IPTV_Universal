package com.cartage

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.lifecycleScope
import com.cartage.core.localization.Language
import com.cartage.ui.CartageApp
import com.cartage.ui.theme.CartageTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CartageTheme { CartageApp(onLanguageSelected = ::changeLanguage) } }
    }

    private fun changeLanguage(language: Language) {
        lifecycleScope.launch {
            CartageApplication.saveLanguage(this@MainActivity, language)
            recreate()
        }
    }
}
